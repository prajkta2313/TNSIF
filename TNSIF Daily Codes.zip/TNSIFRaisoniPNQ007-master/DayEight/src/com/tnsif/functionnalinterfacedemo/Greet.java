package com.tnsif.functionnalinterfacedemo;

@FunctionalInterface
public interface Greet {

	public void greetings();
	
	
	
}
