package com.tnsif.functionnalinterfacedemo;

public class GreetClass implements Greet {

	@Override
	public void greetings() {
		System.out.println("Greet Method");
		
	}

}
