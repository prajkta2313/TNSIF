package com.tnsif.markerinterface;


public interface Registrable {

	
	
}
