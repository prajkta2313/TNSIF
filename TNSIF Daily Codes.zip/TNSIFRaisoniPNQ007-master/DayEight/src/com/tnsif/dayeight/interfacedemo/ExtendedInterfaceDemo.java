package com.tnsif.dayeight.interfacedemo;

public class ExtendedInterfaceDemo implements ChildInterface {

	@Override
	public void show() {
		System.out.println("Show Method");
		
	}

	@Override
	public void display() {
		System.out.println("Display Method");
		
	}

	@Override
	public void addition() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sum() {
		// TODO Auto-generated method stub
		
	}

	

	
}
