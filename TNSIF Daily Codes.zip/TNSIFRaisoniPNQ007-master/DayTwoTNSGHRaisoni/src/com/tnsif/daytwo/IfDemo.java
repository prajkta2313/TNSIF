package com.tnsif.daytwo;

public class IfDemo {

	public static void main(String[] args) {
		
		int x = 12;
		
		if(x<10)
		{
		System.out.println("value of x = " + x);
		}
		
		
//		if(condition)
//		{
//			//code
//		}

	}

}
