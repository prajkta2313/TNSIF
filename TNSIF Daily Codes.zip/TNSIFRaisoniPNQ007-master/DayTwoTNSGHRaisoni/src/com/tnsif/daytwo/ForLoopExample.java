package com.tnsif.daytwo;

public class ForLoopExample {

	public static void main(String[] args) {
		
		for(int i=1; i<=50; i++)
		{
			System.out.println("Value of i : " + i);
			
		}
	

	}

}





//   for(initialization; condition; increment/decrement)
//   {
//	   // code
//   }
