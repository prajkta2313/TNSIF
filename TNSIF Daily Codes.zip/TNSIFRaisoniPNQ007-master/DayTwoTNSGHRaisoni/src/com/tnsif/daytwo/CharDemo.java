package com.tnsif.daytwo;

public class CharDemo {

	public static void main(String[] args) {
	
		// assigning single character literal
		char ch = 'a';
		System.out.println(ch);
		
		// assigning number to char
		char ch1 = 65;
		System.out.println(ch1);
		
		// assingning unicode to char
		
		char vh1 = '\u00A7';
		System.out.println(vh1);

	}

}
