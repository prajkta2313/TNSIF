package com.tnsif.daytwo;

public class IFElseDemo {

	public static void main(String[] args) {
		
    int age = 23;
    
    if(age >18)
    {
    	System.out.println("You are eligivble for vote");
    }
    else
    {
    	System.out.println("Sorry ! you need to wait more");
    }
		
	}

}


//  if(condition)
//  {
//	  // code if condition is true
//  }
//  else
//  {
//	  // code if condition is false
//  }
//  
