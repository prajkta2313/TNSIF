package com.tnsif.dayseven.overriding;

public class Shape {
	
	// member function
	public void draw()
	{
		System.out.println("Drawing a generic shape");
	}
	
	
	public void erase()
	{
		System.out.println("Erasing a generic shape");
	}

}
